import math

def is_prime(n):
    """Check if a number n is prime."""
    if n <= 1:
        return False  # 0 and 1 are not prime
    if n == 2:
        return True   # 2 is prime
    if n % 2 == 0:
        return False  # even numbers > 2 are not prime
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        if n % i == 0:
            return False
    return True

# AI-generated test cases with justification:
# 0, 1 -> Not prime (edge cases)
# 2, 3 -> Prime (smallest primes)
# 4 -> Not prime (even number)
# 17, 19, 97 -> Prime (general primes)
# 18, 20 -> Not prime (composites)

test_cases = {
    0: False,
    1: False,
    2: True,
    3: True,
    4: False,
    17: True,
    18: False,
    19: True,
    20: False,
    97: True
}

# Run tests
for num, expected in test_cases.items():
    result = is_prime(num)
    print(f"is_prime({num}) = {result}, expected = {expected}, {'PASS' if result == expected else 'FAIL'}")
