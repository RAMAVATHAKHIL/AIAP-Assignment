class Rectangle:
    """
    Rectangle class to represent a rectangle shape.

    Attributes:
        width (float): The width of the rectangle.
        height (float): The height of the rectangle.

    Methods:
        area(): Returns the area of the rectangle.
        perimeter(): Returns the perimeter of the rectangle.
    """

    def __init__(self, width, height):
        """
        Initialize a Rectangle instance.

        Args:
            width (float): Width of the rectangle.
            height (float): Height of the rectangle.
        """
        self.width = width  # AI-generated comment: store the rectangle's width
        self.height = height  # AI-generated comment: store the rectangle's height

    def area(self):
        """
        Calculate the area of the rectangle.

        Returns:
            float: Area calculated as width * height
        """
        return self.width * self.height  # multiply width by height to get area

    def perimeter(self):
        """
        Calculate the perimeter of the rectangle.

        Returns:
            float: Perimeter calculated as 2 * (width + height)
        """
        return 2 * (self.width + self.height)  # sum of all sides

# Example usage
rect = Rectangle(5, 10)
print("Area:", rect.area())          # Output: Area: 50
print("Perimeter:", rect.perimeter()) # Output: Perimeter: 30
